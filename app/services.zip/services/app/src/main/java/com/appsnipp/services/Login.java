package com.appsnipp.services;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final TextView registerButton=findViewById(R.id.textviewRegister);
        final EditText editTextLogid=findViewById(R.id.editTextID);
        final EditText editteXTpassword=findViewById(R.id.editTextPassword);
        final ImageView imagereg=findViewById(R.id.loginright);


        imagereg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String IdText=editTextLogid.getText().toString();
                final String Pass=editteXTpassword.getText().toString();

                if (IdText.isEmpty() || Pass.isEmpty()){
                    Toast.makeText(Login.this,"Please Enter your ID NO or Password",Toast.LENGTH_LONG).show();
                }
                else{

                }
            }
        });
    }
}